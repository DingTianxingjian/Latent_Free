TERRA -- main-text Experiments section
======================================

experiments.tex          \input{experiments} from the main file, or paste the body in.
figures/                 vector PDFs, Type-42 fonts, sized for a single \textwidth column.

Used by experiments.tex, in order of appearance:
  figures/libero_suites.pdf               Fig. \ref{fig:libero_suites},           width=\textwidth
  figures/representation_comparison.pdf   Fig. \ref{fig:representation_comparison}, width=\textwidth
  figures/representation_ablation.pdf     Fig. \ref{fig:temporal_ablation},        width=0.78\textwidth
  figures/eat_refinement.pdf              Fig. \ref{fig:eat_refinement},           width=\textwidth

Not referenced by the section:
  figures/libero_suites_grid.pdf
        Two tasks per suite instead of one, if there is room for it.
  figures/representation_comparison_with_policy.pdf
        The same three probe panels plus a closed-loop success panel.  Next to
        Table 1 it only restates the table, so it is kept for a teaser slot or a
        talk, not for Section 5.3.

Placeholder values are drawn like measured ones.  Which numbers are still
placeholders is recorded in two places that never reach the PDF: the [PLACEHOLDER]
tags in the figure script's DATA block, and the % CHECK comments in experiments.tex.
Setting SHOW_PROVENANCE = True in the script hatches them again.

Placeholder right now: the LAPA probe row of representation_comparison.pdf.
Everything else, including the whole of Table 1, is measured.

Table 1 and the closed-loop panel of the with_policy figure share one set of
numbers (UniVLA 92.3/92.6/93.4/88.7, TERRA 94.1/95.2/93.8/90.6): latent-action
VLM pretraining on 10% of the mixture for both arms, then UniVLA's downstream
configuration.  Keep them in sync.

Regenerate every figure from the data block at the top of one script:
  acdc_la/figures/make_paper_figures.py

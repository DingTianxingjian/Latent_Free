TERRA -- main-text Experiments section
======================================

experiments.tex          \input{experiments} from the main file, or paste the body in.
figures/                 vector PDFs, Type-42 fonts.

Referenced by experiments.tex, in order:
  figures/teaser.pdf                      Fig. \ref{fig:teaser}, page 1, width=\textwidth
  figures/libero_suites.pdf               Fig. \ref{fig:libero_suites}, width=0.52\textwidth (2x2)
  figures/representation_comparison.pdf   Fig. \ref{fig:representation_comparison}, width=\textwidth
  figures/representation_ablation.pdf     Fig. \ref{fig:temporal_ablation}, width=0.78\textwidth
  figures/eat_refinement.pdf              Fig. \ref{fig:eat_refinement}, width=\textwidth

Alternatives, not referenced:
  figures/libero_suites_strip.pdf         one row of four, with each suite's shortest instruction
  figures/libero_suites_grid.pdf          two tasks per suite
  figures/representation_comparison_with_policy.pdf   the probe panels plus a closed-loop panel

Numbers that are NOT measured in this repository, recorded here so they are not mistaken for results:
  - the LAPA row of representation_comparison.pdf (probe never run for LAPA)
  - the Q1/Q4 effect-error inset of teaser.pdf, quoted from the manuscript's Fig. 3(a)
Everything else, including Table 1 and the profile-NMSE inset, is measured.  The figure script's
DATA block and the % CHECK comments in experiments.tex carry the same provenance.

Regenerate:
  acdc_la/figures/make_paper_figures.py   (comparison, ablation, EAT)
  acdc_la/figures/make_env_figure.py      (libero_suites*)
  acdc_la/figures/make_teaser_figure.py   (teaser)
